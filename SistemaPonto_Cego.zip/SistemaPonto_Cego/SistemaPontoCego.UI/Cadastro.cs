namespace SistemaPontoCego.UI
{
    public partial class Cadastro : Form
    {
        public Cadastro()
        {
            InitializeComponent();
        }
    }
}
